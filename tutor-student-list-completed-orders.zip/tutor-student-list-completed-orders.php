<?php
/**
 * Plugin Name: Tutor Student List by Completed Orders with Bulk SMS
 * Description: A plugin to list students based on completed orders in WooCommerce, send bulk SMS to customers, and manage SMS API credentials.
 * Version: 2.3
 * Author: Your Name
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Register admin menu and sub-menus
function tslco_register_menu() {
    add_menu_page(
        'Completed Orders Students',
        'Completed Orders Students',
        'manage_options',
        'tutor-student-list-completed-orders',
        'tslco_student_list_page',
        'dashicons-groups',
        6
    );
    add_submenu_page(
        'tutor-student-list-completed-orders',
        'Send Bulk SMS',
        'Send Bulk SMS',
        'manage_options',
        'tutor-bulk-sms',
        'tslco_bulk_sms_page'
    );
    add_submenu_page(
        'tutor-student-list-completed-orders',
        'Manage SMS Credentials',
        'Manage SMS Credentials',
        'manage_options',
        'tutor-manage-credentials',
        'tslco_manage_credentials_page'
    );
}
add_action('admin_menu', 'tslco_register_menu');

// Send Bulk SMS function with message replacement
function tslco_send_bulk_sms($course_id, $message) {
    if (!current_user_can('manage_options')) {
        return;
    }

    $students_phone = array();

    // Get completed orders
    $args = array(
        'status' => 'completed',
        'limit' => -1,
    );
    $orders = wc_get_orders($args);

    if (!empty($orders)) {
        foreach ($orders as $order) {
            $items = $order->get_items();
            foreach ($items as $item) {
                $product_id = $item->get_product_id();
                if ($product_id == $course_id) {
                    $student_id = $order->get_user_id();
                    
                    // Get the user data for the student
                    $student = get_userdata($student_id);
                    
                    // Check if user data is valid before proceeding
                    if ($student !== false) {
                        $phone_number = get_user_meta($student_id, 'billing_phone', true);

                        // Get the first name from user meta or the display name
                        $first_name = get_user_meta($student_id, 'first_name', true);

                        if (empty($first_name)) {
                            // If first name is not available, use the first part of display_name
                            $first_name = explode(' ', $student->display_name)[0];
                        }

                        // Replace placeholders in the message
                        $custom_message = str_replace(
                            ['{id}', '{name}'],
                            [$order->get_id(), $first_name], // Use first name
                            $message
                        );

                        $students_phone[] = [
                            'phone' => $phone_number,
                            'message' => $custom_message
                        ];
                    } else {
                        // Handle case where student data is not found (guest checkout, etc.)
                        // You can log this or handle it based on your logic
                    }
                }
            }
        }
    }



    // Send SMS to each customer
    foreach ($students_phone as $student_data) {
        $csmsId = uniqid(); // Unique ID for each message
        tslco_send_single_sms($student_data['phone'], $student_data['message'], $csmsId);
    }

    // Return success message
    return count($students_phone) . " SMS sent successfully.";
}

// Send Single SMS function
function tslco_send_single_sms($msisdn, $messageBody, $csmsId) {
    $params = [
        "api_token" => tslco_get_sms_credential('api_token'),
        "sid" => tslco_get_sms_credential('sid'),
        "msisdn" => $msisdn,
        "sms" => $messageBody,
        "csms_id" => $csmsId
    ];

    $url = rtrim(tslco_get_sms_credential('domain'), '/') . "/api/v3/send-sms";
    $params = json_encode($params);

    $response = tslco_call_api($url, $params);
    return $response;
}

// Call API function
function tslco_call_api($url, $params) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'Content-Length: ' . strlen($params),
        'accept:application/json'
    ));

    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
}

// Save and retrieve SMS credentials
function tslco_get_sms_credential($key) {
    $credentials = get_option('tslco_sms_credentials', array(
        'api_token' => '',
        'sid' => '',
        'domain' => ''
    ));
    return isset($credentials[$key]) ? $credentials[$key] : '';
}

function tslco_update_sms_credentials($api_token, $sid, $domain) {
    $credentials = array(
        'api_token' => $api_token,
        'sid' => $sid,
        'domain' => $domain
    );
    update_option('tslco_sms_credentials', $credentials);
}

// Display the "Manage SMS Credentials" page
function tslco_manage_credentials_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    // Handle form submission
    if (isset($_POST['update_credentials'])) {
        $api_token = sanitize_text_field($_POST['api_token']);
        $sid = sanitize_text_field($_POST['sid']);
        $domain = sanitize_text_field($_POST['domain']);

        tslco_update_sms_credentials($api_token, $sid, $domain);
        echo '<div class="updated"><p>Credentials updated successfully!</p></div>';
    }

    // Retrieve current credentials
    $api_token = tslco_get_sms_credential('api_token');
    $sid = tslco_get_sms_credential('sid');
    $domain = tslco_get_sms_credential('domain');

    ?>
    <div class="wrap">
        <h1>Manage SMS Credentials</h1>
        <form method="POST">
            <table class="form-table">
                <tr>
                    <th scope="row">API Token</th>
                    <td><input type="text" name="api_token" value="<?php echo esc_attr($api_token); ?>" required /></td>
                </tr>
                <tr>
                    <th scope="row">SID</th>
                    <td><input type="text" name="sid" value="<?php echo esc_attr($sid); ?>" required /></td>
                </tr>
                <tr>
                    <th scope="row">API Domain</th>
                    <td><input type="text" name="domain" value="<?php echo esc_attr($domain); ?>" required /></td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="update_credentials" value="Save Changes" class="button button-primary" />
            </p>
        </form>
    </div>
    <?php
}

// Display the student list page
function tslco_student_list_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    // Check if a user is to be deleted
    if (isset($_GET['delete_student']) && current_user_can('delete_users')) {
        $student_id_to_delete = intval($_GET['delete_student']);
        if ($student_id_to_delete) {
            wp_delete_user($student_id_to_delete); // Delete the user
            echo '<div class="notice notice-success is-dismissible"><p>Student deleted successfully.</p></div>';
        }
    }

    $selected_course_id = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;

    // Get current page number, default is 1
    $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;

    // Number of students to show per page
    $students_per_page = 20;

    // Get all courses (WooCommerce products)
    $courses = get_posts(array(
        'post_type' => 'product',
        'posts_per_page' => -1,
        'post_status' => 'publish',
    ));

    ?>
    <div class="wrap">
        <h1>Students from Completed Orders</h1>
        <form method="GET">
            <input type="hidden" name="page" value="tutor-student-list-completed-orders">
            <select name="course_id">
                <?php foreach ($courses as $course) : ?>
                    <option value="<?php echo $course->ID; ?>" <?php selected($selected_course_id, $course->ID); ?>><?php echo esc_html($course->post_title); ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="button">Show Students</button>
        </form>

        <?php if ($selected_course_id) : ?>
            <h2>Student List for Course: <?php echo get_the_title($selected_course_id); ?></h2>

            <?php
            // Get completed orders for the selected course
            $args = array(
                'status' => 'completed',
                'limit' => -1,
            );
            $orders = wc_get_orders($args);
            $students = array();

            // Get students from the orders
            if (!empty($orders)) {
                foreach ($orders as $order) {
                    $items = $order->get_items();
                    foreach ($items as $item) {
                        $product_id = $item->get_product_id();
                        if ($product_id == $selected_course_id) {
                            $student_id = $order->get_user_id();
                            $student = get_userdata($student_id); // Fetch user data
                            $phone_number = get_user_meta($student_id, 'billing_phone', true); // Get phone number
            
                            // Check if $student is valid before accessing its properties
                            if ($student) {
                                $students[] = array(
                                    'id' => $student_id,
                                    'name' => $student->display_name,
                                    'email' => $student->user_email,
                                    'phone' => $phone_number,
                                );
                            } else {
                                // Handle the case where the student is not found
                                $students[] = array(
                                    'id' => 0, // No valid student ID
                                    'name' => 'User not found',
                                    'email' => 'N/A',
                                    'phone' => $phone_number,
                                );
                            }
                        }
                    }
                }
            }

            // Total students
            $total_students = count($students);

            // Calculate the offset and slice the array for the current page
            $offset = ($paged - 1) * $students_per_page;
            $students_page = array_slice($students, $offset, $students_per_page);

            // Display the table with paginated students
            if (!empty($students_page)) : ?>
                <table class="widefat">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone Number</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students_page as $student) : ?>
                            <tr>
                                <td><?php echo esc_html($student['name']); ?></td>
                                <td><?php echo esc_html($student['email']); ?></td>
                                <td><?php echo esc_html($student['phone']); ?></td>
                                <td>
                                    <?php if ($student['id']) : ?>
                                        <!-- Add an onclick confirmation before deletion -->
                                        <a href="<?php echo esc_url(add_query_arg(array('delete_student' => $student['id']))); ?>"
                                           class="button delete-student"
                                           onclick="return confirm('Are you sure you want to delete this student?');">
                                           Delete
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <?php
                // Pagination
                $total_pages = ceil($total_students / $students_per_page);
                if ($total_pages > 1) {
                    echo '<div class="tablenav"><div class="tablenav-pages">';
                    echo paginate_links(array(
                        'base' => add_query_arg('paged', '%#%'),
                        'format' => '',
                        'current' => $paged,
                        'total' => $total_pages,
                        'prev_text' => __('&laquo; Previous'),
                        'next_text' => __('Next &raquo;'),
                    ));
                    echo '</div></div>';
                }
                ?>

                <!-- Display the total number of students -->
                <div style="margin-top: 20px;">
                    <strong>Total Students who bought this course: <?php echo $total_students; ?></strong>
                </div>
            <?php else : ?>
                <p>No students found for this course.</p>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <?php
}



// Display the Bulk SMS page
function tslco_bulk_sms_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    if (isset($_POST['send_sms'])) {
        $course_id = intval($_POST['course_id']);
        $message = sanitize_textarea_field($_POST['message']);

        $sms_sent = tslco_send_bulk_sms($course_id, $message);
        echo '<div class="updated"><p>' . $sms_sent . '</p></div>';
    }

    $courses = get_posts(array(
        'post_type' => 'product',
        'posts_per_page' => -1,
        'post_status' => 'publish',
    ));

    ?>
    <div class="wrap">
        <h1>Send Bulk SMS to Students</h1>
        <form method="POST">
            <table class="form-table">
                <tr>
                    <th scope="row">Select Course</th>
                    <td>
                        <select name="course_id" required>
                            <?php foreach ($courses as $course) : ?>
                                <option value="<?php echo $course->ID; ?>"><?php echo esc_html($course->post_title); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Message</th>
                    <td>
                        <textarea name="message" rows="5" cols="50" required></textarea><br>
                        <small>You can use placeholders: <strong>{id}</strong> for order ID and <strong>{name}</strong> for customer name.</small>
                    </td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="send_sms" value="Send SMS" class="button button-primary" />
            </p>
        </form>
    </div>
    <?php
}




























